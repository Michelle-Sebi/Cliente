# In-memory database to store chats
# chats = []

chats = [
    {"id": 4, "title": "Redis Docker Container Persistence"},
    {"id": 9, "title": "Evento de fila corrigido."},
    {"id": 7, "title": "Debug BullMQ Configuration"},
    {"id": 15, "title": "Docker exercise: Two containers."},
    {"id": 1, "title": "Client and Consumer: BullMQ"},
    {"id": 3, "title": "Set Redis Password programmatically"},
    {"id": 14, "title": "Redis Docker Password Setup"},
    {"id": 2, "title": "Sum 1/z as sumatory"},
    {"id": 13, "title": "Python .gitignore para pytame"},
    {"id": 8, "title": "Pygame Fenêtre Sur Deux Moniteurs"},
    {"id": 11, "title": "Shell Scripting Exercises"},
    {"id": 6, "title": "Read File Lines Bash"},
    {"id": 17, "title": "Exclude Directories: Java Settings"},
    {"id": 10, "title": "DisplayName Import Correction"},
    {"id": 5, "title": "Debouncing Hook in JS"},
    {"id": 12, "title": "Maven Unit Test Setup"},
    {"id": 16, "title": "JUnit Testing: Banana Class"}
]
